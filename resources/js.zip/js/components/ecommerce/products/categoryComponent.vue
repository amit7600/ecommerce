<template>
    <div>
        <div class="product-big-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="product-bit-title text-center">
                            <h2>{{ $t('category') }}</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- End Page title area -->

        <!-- <div class="col-sm-md-12">
            <div class="single-product-area">
                <div class="zigzag-bottom"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 col-sm-6" v-for="(cat, index) in category" :key="index">
                            <div class="single-shop-product">
                                <div class="product-upper">
                                    <img src="img/product-1.jpg" alt="">
                                </div>
                                <h2><a href="">Apple new mac book 2015 March :P</a></h2>
                                <div class="product-carousel-price">
                                    <ins>$899.00</ins> <del>$999.00</del>
                                </div>  
                                
                                <div class="product-option-shop">
                                    <a class="add_to_cart_button" data-quantity="1" data-product_sku="" data-product_id="70" rel="nofollow" href="/canvas/shop/?add-to-cart=70">Add to cart</a>
                                </div>                       
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="product-pagination text-center">
                                <nav>
                                <ul class="pagination">
                                    <li>
                                    <a href="#" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                    </li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li>
                                    <a href="#" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                    </li>
                                </ul>
                                </nav>                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->


      <!-- Start Category page  -->
   
        <div class="feature_product category_page">
                                <div class="container">
                                        <div class="item" >
                                            <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/almonds.jpg" alt="" title="" class="image" >
                                                    <div class="middle">
                                                        <div class="inner_middle">
                                                            <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                            <h3 class="text">ALMONDS</h3>
                                                        </div>
                                                    </div>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/anjeer.jpg" alt="" title="" class="image">
                                                        <div class="middle">
                                                            <div class="inner_middle">
                                                                <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                                <h3 class="text">ALMONDS</h3>
                                                            </div>
                                                        </div>      
                                                    </a>  
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="item">
                                        <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/kaju.jpg" alt="" title="" class="image">

                                                        <div class="middle">
                                                            <div class="inner_middle">
                                                                <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                                <h3 class="text">ALMONDS</h3>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="item">
                                        <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/pista.jpg" alt="" title="" class="image">

                                                        <div class="middle">
                                                            <div class="inner_middle">
                                                                <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                                <h3 class="text">ALMONDS</h3>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/anjeer.jpg" alt="" title="" class="image">

                                                        <div class="middle">
                                                            <div class="inner_middle">
                                                                <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                                <h3 class="text">ALMONDS</h3>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="inner_product">
                                                <div class="product_img">
                                                    <a href="#"><img src="/ecommerce/img/kaju.jpg" alt="" title="" class="image">

                                                        <div class="middle">
                                                            <div class="inner_middle">
                                                                <img  src="/ecommerce/img/almonds_overlay.png" alt="" title="" class="text" >
                                                                <h3 class="text">ALMONDS</h3>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                                
                                            </div>
                                        </div>

                                   
                                </div>
                            </div>    

      <!-- End Category -->

    </div>
</template>

<script>
export default {
    data () {
        return {
            category: []
        }
    }
}
</script>

<style>

</style>

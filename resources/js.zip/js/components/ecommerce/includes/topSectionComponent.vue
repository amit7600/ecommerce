<template>
    <div>
        <!-- alert error message -->        
        <div  v-if="errorMessage.length > 0" class="alert alert-danger alert-dismissible fade in">
            <a class="close" data-dismiss="alert" aria-label="close" @click="emptyMessage">&times;</a>
            <strong v-for="(er,index) in errorMessage" :key="index" > {{ er }} </strong>
        </div>
        <!-- alert success message -->
        <div v-if="successMessage.length > 0" class="alert alert-success alert-dismissible fade in">
            <a class="close" data-dismiss="alert" aria-label="close" @click="emptyMessage">&times;</a>
            <strong v-for="(ss,index) in successMessage" :key="index" > {{ ss }} </strong>
        </div>

       <div class="header-area">
            <div class="container">
                <div class="">
                    <div class="social_icon">
                        <ul>
                            <li><a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" title="Google Plus"><i class="fab fa-google-plus-g"></i></a></li>
                            <li><a href="#" title="Linked In"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="top_header_menu">
                        <div class="user-menu">
                            <ul>
                                <li class="dropdown">
                                    <router-link  to="#" ><i class="fas fa-language"> </i> {{ $i18n.locale == 'ar' ? $t('arabic') : $t('english')   }}  <img src="/ecommerce/img/down_arrow.png" alt="" title="" class="down_arrow"></router-link>
                                    <ul class="dropdown-menu">
                                        <li><a @click="setLocale('en')">{{ $t('english') }}</a></li>
                                        <li><a @click="setLocale('ar')">{{ $t('arabic') }}</a></li> 
                                    </ul>
                                </li>
                                <!-- <li class="dropdown">
                                    <router-link  to="#" ><i class="fas fa-dollar-sign"></i> USD <img src="/ecommerce/img/down_arrow.png" alt="" title="" class="down_arrow"></router-link>
                                    <ul class="dropdown-menu">
                                        <li><a href="#"><i class="fas fa-dollar-sign"></i> USD </a></li>
                                        <li><a href="#"><i class="fas">د.إ </i> AED </a></li>
                                    </ul>
                                </li> -->
                                <li class="dropdown">
                                    <router-link  to="#" ><i class="fa fa-user"></i> {{ $t('myAccount') }} <img src="/ecommerce/img/down_arrow.png" alt="" title="" class="down_arrow"></router-link>
                                    <ul class="dropdown-menu">
                                        <li v-if="!isLogin" @click="showModal(true)"><a ><i class="fas fa-lock"></i> {{ $t('login') }}</a></li>
                                        <li v-if="!isLogin" @click="showModal(false)"><a ><i class="fas fa-user-plus"></i> {{ $t('register') }}</a></li>
                                        <li v-if="isLogin" ><router-link  v-if="isLogin" to="/myAccount"><i class="fa fa-user"></i> {{ $t('myAccount') }}</router-link></li>
                                        <li v-if="isLogin" @click="logOut"><a ><i class="fas fa-sign-out-alt"></i> {{ $t('logOut') }}</a></li> 
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- End header area -->
        <div id="example-modal">
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form id="msform">
                        <fieldset class="login_form">
                            <h2><img src="/ecommerce/img/logo.png" alt=" " title=""></h2>
                            <h2 v-if="signUp == true" class="fs-title">{{ $t('login') }}</h2>
                            <h2 v-else class="fs-title">{{ $t('register') }}</h2>
                            <div v-if="!signUp">
                                <div class="form-group">
                                 <label for="phone_id" class="control-label">{{ $t('firstName') }}</label>
                                <input type="text" name="firstname" :placeholder="$t('firstName')" data-vv-name="firstname" data-vv-as="First Name" v-validate="'required'"  :class="{'alert-danger': errors.has('firstname')}" v-model="firstName" />
                                </div>
<!-- <span>{{ errors.first('firstname') }}</span> -->
                                <div class="form-group">
                                 <label for="phone_id" class="control-label">{{ $t('lastName') }}</label>
                                <input type="text" name="lname" :placeholder="$t('lastName')"  data-vv-name="lastName" v-validate="'required'"  :class="{'alert-danger': errors.has('lastName')}" v-model="lastName" />
                                </div>
                                <div class="form-group">
                                 <label for="phone_id" class="control-label">{{ $t('mobile') }}</label>
                                <input type="text" name="phone" :placeholder="$t('mobile')"  data-vv-name="phone" v-validate="'required|numeric'"  :class="{'alert-danger': errors.has('phone')}" v-model="mobileNumber" />
                                </div>
                            </div>
                             <div class="form-group">
                            <label for="phone_id" class="control-label">{{ $t('email') }}</label>
                            <input type="email" name="emails" :placeholder="$t('email')"  data-vv-name="email" v-validate="'required|email'"  :class="{'alert-danger': errors.has('email')}" @keyup.enter="userLogin" v-model="email" />
                             </div>
                            <div class="form-group">
                            <label for="phone_id" class="control-label">{{ $t('password') }}</label>
                            <input type="password" name="passwords" :placeholder="$t('password')" data-vv-name="password" v-validate="'required'"  :class="{'alert-danger': errors.has('password')}" ref="password" @keyup.enter="userLogin" v-model="password" />
                            </div>
                             <div class="form-group">
                            <label v-if="!signUp" for="phone_id" class="control-label">{{ $t('confirmPassowrd') }}</label>
                            <input type="password" name="password" :placeholder="$t('confirmPassowrd')" v-if="!signUp" data-vv-name="confirmPassowrd" v-validate="'required|confirmed:password'"  :class="{'alert-danger': errors.has('confirmPassowrd')}" v-model="confirmPassword" />
                            </div>
                             <div class="form-group">
                            <label v-if="!signUp" for="phone_id" class="control-label">{{ $t('countryCode') }}</label> 
                            <select name="country" id=""  v-if="!signUp" v-model="countryCode">
                                <option v-for="(count, index) in country" :key="index" :value="count.dial_code" :selected="count.dial_code == 971">  {{ count.dial_code }} - {{ count.name }}</option>
                            </select>
                             </div>
                            <!-- <input v-if="signUp == true" type="button" name="next" class="next action-button" :value="$t('login')" @click="userLogin" />

                            <input v-else type="button" name="next" class="next action-button" :value="$t('register')" @click="userLogin" /> -->
                            <div class="shipping_btn">
                                <button type="button" class="" v-if="signUp == true" @click="userLogin">{{ $t('login') }}</button>

                                <button v-else type="button" name="next"  @click="userLogin">{{ $t('register') }}</button>
                                    <a @click="signUp = false" v-if="signUp == true">{{ $t('register') }}</a>
                                            <a @click="signUp = true" v-if="signUp == false">{{ $t('login') }}</a>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions  } from 'vuex'
export default {
    computed: {
        ...mapState([
            'getLocale',
            'isLogin',
            'errorMessage',
            'successMessage',
            'country',

        ]),
    },
    data (){
        return {
            signUp: true,
            firstName: '',
            lastName: '',
            email: '',
            password: '',
            confirmPassword: '',
            countryCode: 971,
            mobileNumber: '',
        }
    },
    mounted() {
        if(this.$session.has('locale')) this.setLocale(this.$session.get('locale'));
    },
    methods: {
        ...mapActions([
            'ACTION_SET_LOCALE',
            'ACTION_IS_LOGIN',
            'ACTION_PUSH_SUCCESS',
            'ACTION_PUSH_ERROR',
            'ACTION_NULL_MESSAGES',
            'ACTION_CHANGE_RTL',
        ]),
        setLocale (lang) {
            // Set language
            this.$session.set('locale', lang)
            this.$i18n.locale = lang
            this.$validator.locale = lang;
            if (lang == 'ar') {
                this.ACTION_CHANGE_RTL('rtl')
            } else {
                this.ACTION_CHANGE_RTL('ltr')
            }
            this.ACTION_SET_LOCALE(lang)
        },
        logOut () {
            this.$session.clear();
            this.checkLogin()
            this.$router.push('/')
            location.reload();
        },
        showModal(value) {
            // open login model
            this.signUp = value;
            $('#exampleModal').modal('show')
        },
        userLogin () {
            if (this.signUp) {
                this.$validator.validateAll().then(result => {
                    if(result) {
                        axios.post('/api/login', {
                            email: this.email,
                            password: this.password,
                        })
                        .then (response => {
                            var access = 'Bearer ' + response.data.accessToken
                            this.$session.set('accessToken', access)
                            this.$session.set('isLogin', true)
                            this.checkLogin() // call parent function to set login variable
                            $('#exampleModal').modal('hide')
                            location.reload(); // For reload windows
                        })
                        .catch (errorResponse => {
                            console.log(errorResponse)
                        })
                    }
                })
            } else {
                // register user
                this.register()
            }
        },
        checkLogin () {
            if(this.$session.has('isLogin') && this.$session.get('isLogin') == true) {
                this.ACTION_IS_LOGIN(true)
            } else {
                this.ACTION_IS_LOGIN(false)
            }
        },
        emptyMessage () {
            this.ACTION_NULL_MESSAGES()
        },
        register () {
            this.$validator.validateAll().then(result => {
                if(result) {
                    axios.post('/api/users', {
                        first_name: this.firstName,
                        last_name: this.lastName,
                        email: this.email,
                        password: this.password,
                        confirm_password: this.confirmPassword,
                        country_code: this.countryCode,
                        mobile_number: this.mobileNumber,
                    })
                    .then (response => {
                        var access = 'Bearer ' + response.data.accessToken
                        this.$session.set('accessToken', access)
                        this.$session.set('isLogin', true)
                        this.checkLogin() // call parent function to set login variable
                        $('#exampleModal').modal('hide')
                        location.reload(); // For reload windows
                    })
                    .catch (errorResponse => {
                        console.log(errorResponse)
                    })
                }
            });
        },
    }
}
</script>

<style>

</style>

<template>
    <div>
        <ShippingAddressComponent></ShippingAddressComponent>
    </div>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions } from "vuex";
import ShippingAddressComponent from '../orders/shippingAddressComponent';
export default {
    components: {
        ShippingAddressComponent,
    },
}
</script>

<style>

</style>

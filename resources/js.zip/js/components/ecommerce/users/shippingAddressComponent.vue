<template>
    <div>
        <div v-for="(ship, index) in shippingAddress" :key="index">
            {{ ship.id }}
        </div>
    </div>
</template>

<script>
export default {
    data () {
        return {
            shippingAddress: [],
        }
    },
    mounted () {
        this.getShippingAddress()
    },
    methods: {
        getShippingAddress () {
            axios.get('/api/shippingAddress', {
                headers: {
                        Authorization: this.$session.get('accessToken')
                    }
            })
            .then (response => {
                this.shippingAddress = response.data.data
            })
        }
    }
}
</script>

<style>

</style>

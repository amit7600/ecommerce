<template>
    <div>
        <div class="container">

            <div class="item_container">
                <h4>{{ $t('thankYou') }}</h4>
                <p> Lorem ipsum dolor sit amet, nostrud nominati vis ex, essent conceptam eam ad. Cu etiam comprehensam nec. Cibo delicata mei an, eum porro legere no. Te usu decore omnium, quem brute vis at, ius esse officiis legendos cu. Dicunt voluptatum at cum. Vel et facete equidem deterruisset, mei graeco cetero labores et. Accusamus inciderint eu mea.</p>

                <div class="content_ship_address">
                    <div class="form_title">
                        <h4> <img src="/ecommerce/img/title_icon1.png" alt="" title=""> Shipping Address <img src="/ecommerce/img/title_icon_mirror1.png" alt="" title=""></h4></div>
                    <table class="table table-striped confirm">
                        <tbody>
                            <tr>
                                <td>
                                    <strong>{{$t('name')}}</strong>
                                </td>
                                <td>
                                    {{ this.orderDetails }}
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>Address</strong>
                                </td>
                                <td>
                                    128/2
                                </td>
                            </tr>
                            <tr>
                                <td><strong>City</strong>
                                </td>

                                <td>
                                    Ahmedabad
                                    <br>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>mobile</strong>
                                </td>
                                <td>22131313131</td>
                            </tr>
                            <tr>
                                <td><strong>Address Type</strong>
                                </td>
                                <td>Home</td>
                            </tr>
                            <tr>
                                <td><strong>landmark</strong>
                                </td>
                                <td>IIT college</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <table border="1" class="table table-hover order_place">
                    <thead>
                        <tr>
                            <th>{{$t('product')}}</th>
                            <th>Title</th>
                            <th>{{$t('quantity')}}</th>
                            <th class="text-center">{{$t('price')}}</th>
                            <th class="text-center">{{$t('total')}}</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr  v-for="(order, index) in orderDetails" :key="index">
                            <td class="col-sm-1 col-md-1">
                                <div class="media">
                                    <a class="thumbnail pull-left"> <img class="media-object" :src="cart.productData.product_other_image[0]" style="width: 72px; height: 72px;"> </a>
                                </div>
                            </td>
                            <td class="col-sm-1 col-md-1 table_order">
                                <h4><a>{{getLocale == 'ar' ? cart.productData.product_name_arabic : cart.productData.product_name }}</a></h4>
                                <!-- <h5> by <a href="#">Brand name</a></h5> -->
                            </td>
                            <td class="col-sm-1 col-md-1 Quanity" style="text-align: center">
                                <input type="email" class="form-control" id="exampleInputEmail1" value="3">
                            </td>
                            <td class="col-sm-1 col-md-1 text-center"><strong>{{cart.price }}</strong></td>
                            <td class="col-sm-1 col-md-1 text-center"><strong>{{ cart.quantity * cart.price }}</strong></td>
                        </tr>
                    </tbody>
                </table>

                <div class="order_summary_container">
                    <div class="coupon_code">
                        <h2><img src="/ecommerce/img/title_icon1.png" alt="" title="">Order summary <img src="/ecommerce/img/title_icon_mirror1.png" alt="" title=""></h2></div>
                    <div class="coupon_code">
                        <p>{{ $t('subTotal') }}
                            <span class="amount">AED 90</span></p>
                        <p>{{ $t('shippingCharge') }}
                            <span>{{ $t('freeShipping') }}</span></p>
                        <p>{{ $t('discount') }}
                            <span class="amount"> AED 0</span></p>
                        <p>{{ $t('total') }}
                            <span class="amount">AED 90</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<!-- <table cellspacing="0" class="shop_table cart">
            <thead>
                <tr>

                    <th class="product-name">{{$t('product')}}</th>
                    <th class="product-price">{{$t('price')}}</th>
                    <th class="product-quantity">{{$t('quantity')}}</th>
                    <th class="product-subtotal">{{$t('total')}}</th>
                </tr>
            </thead>
            <tbody>
                <tr class="cart_item" v-for="(cart, index) in cartList" :key="index">                                     
                    <td class="product-thumbnail">
                        <a href="single-product.html"><img alt="poster_1_up" class="shop_thumbnail" :src="cart.productData.product_other_image[0]"></a>
                    </td>
                    <td class="product-name">
                        <a href="">
                            {{getLocale == 'ar' ? cart.productData.product_name_arabic : cart.productData.product_name }}
                        </a> 
                    </td>

                    <td class="product-price">
                        <span class="amount">{{ $t('aed') }} {{cart.price }}</span> 
                    </td>

                    <td class="product-quantity">
                        <div class="quantity buttons_added">
                            {{ cart.quantity }}
                        </div>
                    </td>

                    <td class="product-subtotal">
                        <span class="amount">{{ $t('aed') }} {{ cart.quantity * cart.price }}</span> 
                    </td>
                </tr>

            </tbody>
        </table> -->

<!-- <div class="cart_item"  v-for="(cart, index) in cartList" :key="index">
                        <div class="image_container">
                            <a @click="$parent.setImage(cart.productData.product_other_image[0], cart.productId)"><img  alt="poster_1_up" class="shop_thumbnail" :src="cart.productData.product_other_image[0]"></a> 
                        </div>
                        <div class="detail_container">
                            <h2><a @click="$parent.setImage(cart.productData.product_other_image[0], cart.productId)">
                                {{getLocale == 'ar' ? cart.productData.product_name_arabic : cart.productData.product_name }}
                                </a>
                            </h2>  

                            <p v-html="getLocale == 'ar' ? cart.productData.product_description_arabic : cart.productData.product_description"></p>
                        </div>
                        <div class="prooduct_price"> 
                            <h3 class="price_tag">{{ $t('price') }} : <span class="price">{{ $t('aed') }} {{cart.price }}</span></h3>
                            <div class="product_quantity buttons_added">
                                <input type="button" class="minus quantity-left-minus btn btn-danger btn-number" value="-" @click="$parent.removeFromCart(cart.productId)">

                                <input type="number" size="4" class="input-text qty txt" title="Qty" :value="cart.quantity"  @input="changeCart(cart.productId, cart.price, index)" min="1" step="1" :id="'quantity_'+index">

                                <input type="button" class="plus quantity-right-plus btn btn-success btn-number" value="+" @click="$parent.addToCart(cart.productId, cart.price)">
                            </div>
                            <div class="product_subtotal">
                                <h3 class="price_tag">{{ $t('totalPrice') }} : <span class="price ">{{ $t('aed') }} {{ cart.quantity * cart.price }}</span></h3>
                            </div>
                        </div>
                  </div>           -->

<!-- start cart palceorder -->

<!-- end -->

<!-- <div >
         <div class="container" >
            <div class="col-md-2">
               <div class="card">
                  <div class="image pull-left">
                  </div>
                  <div class="pull-right">
                  </div>
                  <div class="content pull-left">
                     <h4>{{shippingAddress.full_name}}</h4>
                     <div> 
                        {{shippingAddress.address}}
                        <br>
                            {{shippingAddress.city}}
                        <br>
                            {{shippingAddress.mobile_number}}
                        <br>
                            {{shippingAddress.address_type}}
                     </div>
                  </div>
                  <div class="clearfix">
                  </div>
               </div>
            </div>
         </div>
         <div class="grand-total">
             <div class="cart_totals ">
                <h2>{{ $t('cartTotal') }}</h2>

                <table cellspacing="0">
                    <tbody>
                        <tr class="cart-subtotal">
                            <th>{{ $t('cartSubTotal') }}</th>
                            <td><span class="amount">{{ $t('aed') }} {{ subTotal ? subTotal : CART_TOTAL_PRICE }}</span></td>
                        </tr>

                        <tr class="shipping">
                            <th>{{ $t('shippingAndHandling') }}</th>
                            <td>{{ $t('freeShipping') }}</td>
                        </tr>

                        <tr >
                            <th>{{ $t('discount') }}</th>
                            <td class="product-remove">{{ discount }}</td>

                        </tr>

                        <tr class="order-total">
                            <th>{{ $t('orderTotal') }}</th>
                            <td><strong><span class="amount">{{ $t('aed') }} {{ grandTotal ? grandTotal : CART_TOTAL_PRICE }}</span></strong> </td>
                        </tr>

                    </tbody>
                </table>

            </div>
         </div>
      </div>

      <input type="button" :value="$t('placeOrder')" @click="palceOrder" />  -->
<script>
import { mapState, mapMutations, mapGetters, mapActions } from "vuex";
export default {
    computed: {
        ...mapState([
            'cartList',
            'getLocale',
            'shippingAddress',
            'couponCode',
            'subTotal',
            'discount',
            'tax',
            'shippingCharge',
            'grandTotal',
        ]),
        ...mapGetters([
            'PRODUCT_FILTER',
            'CART_TOTAL_PRICE',
        ])
    },
    data () {
        return {
            orderDetails: [],
        }
    },
    created () {
        this.getOrder()
    },
    mounted() {
        // if the coupon code is find
        this.applyExistCoupon()
    },
    methods: {
        ...mapActions ([
            'SET_CART',
            'ACTION_ACTIVE_CLASS',
            'APPLY_COUPON',
            'ACTION_CALCULATE_TOTAL',
            'ACTION_PUSH_SUCCESS',
            'ACTION_PUSH_ERROR',
        ]),
        applyExistCoupon () {
            if(this.$session.has('couponCode') && this.$session.get('couponCode')) {
                this.APPLY_COUPON({couponCode:this.$session.get('couponCode'), couponData: this.$session.get('couponData')})
                this.isCouponCode = true
            } else {
                this.ACTION_CALCULATE_TOTAL({cartTotalPrice: 0})
            }
        },
        palceOrder () {
            // order Place
            axios.defaults.headers.common['Authorization'] = this.$session.get('accessToken')
            axios.post('/api/orders', {
                cartList: this.cartList,
                getLocale: this.getLocale,
                shippingAddress: this.shippingAddress,
                couponCode: this.couponCode,
                subTotal: this.subTotal,
                discount: this.discount,
                tax: this.tax,
                shippingCharge: this.shippingCharge,
                grandTotal: this.grandTotal,
                shipingId: this.$session.get('shippingId'),
                paymentMethod: this.$session.get('paymentMethod'),
            })
            .then(response => {
                localStorage.removeItem("cart")
                this.$session.remove('shippingId')
                this.$session.remove('shippingAddress')
                this.$session.remove('couponCode')
                this.$session.remove('paymentMethod')
                // this.$router.push('/orderSuccess')
                this.ACTION_PUSH_SUCCESS(this.$t('orderPlaceSuccessfully'))
                this.getLastOrder()
                // location.reload();
            })
            .catch(errorResponse => {
                console.log(errorResponse.response)
            })
        },
        getLastOrder () {
            axios.get('/api/orders', {
                headers: {
                    Authorization:this.$session.get('accessToken')
                }
            })
            .then ( response => {
                this.orderDetails = response.data.data
            })
            .catch (errorReponse => {
                console.log(errorReponse, 'errorReponse')
            })
        },
        getOrder () {
            axios.get('/api/orders/' + this.$session.get('orderId'), {
                headers: {
                    Authorization:this.$session.get('accessToken')
                }
            })
            .then ( response => {
                this.orderDetails = response.data.data
            })
            .catch (errorReponse => {
                console.log(errorReponse, 'errorReponse')
            })
        }
    }
}
</script>

<style>

</style>

import Vue from 'vue';
import Router from 'vue-router';

import HomeComponent from './components/ecommerce/homeComponent.vue';
import CartComponent from './components/ecommerce/orders/cartComponent';
import CheckOutComponent from './components/ecommerce/orders/checkoutComponent';
import OrderSuccessComponent from './components/ecommerce/orders/orderSuccessComponent';
import MyAccountComponent from './components/ecommerce/users/myAccountComponent';
import CategoryComponent from './components/ecommerce/products/categoryComponent';
import SearchComponent from './components/ecommerce/products/searchComponent';
import ProductDetailsComponent from './components/ecommerce/products/productDetailsComponent';
import ChildHomeComponent from './components/ecommerce/includes/childHomeComponent';
import ShippingAddressComponent from './components/ecommerce/users/shippingAddressComponent';

Vue.use(Router)

// export start
export default new Router({
    routes: [
        {
          path: '/',
          component: HomeComponent,
          children: [
            {
              path: '/',
              name: 'ChildHomeComponent',
              component: ChildHomeComponent
            },
            {
              path: '/cart',
              name: 'CartComponent',
              component: CartComponent
            },
            {
              path: '/checkout',
              name: 'CheckOutComponent',
              component: CheckOutComponent,
            },
            {
              path: '/orderSuccess',
              name: 'OrderSuccessComponent',
              component: OrderSuccessComponent,
            },
            {
              path: '/myAccount',
              name: 'MyAccountComponent',
              component: MyAccountComponent,
            },
            {
              path: '/categories',
              name: 'CategoryComponent',
              component: CategoryComponent,
            },
            {
              path: '/product-details/:id',
              name: 'ProductDetailsComponent',
              component: ProductDetailsComponent,
            },
            {
              path: '/search/:id',
              name: 'SearchComponent',
              component: SearchComponent,
            },
            {
              path: '/shippinAddress',
              name: 'ShippingAddressComponent',
              component: ShippingAddressComponent,
            }
          ]
        },
        
    ],
    mode: 'history',
})
// export end